function [Frequency]=AminoAcidFrequency(x)

index=find('A'==x);
a = size(index,2);
Frequency=[];
Frequency=[Frequency a];

index=find('C'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('D'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('E'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('F'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('G'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('H'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('I'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('K'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('L'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('M'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('N'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('P'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('Q'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('R'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('S'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('T'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('V'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('W'==x);
a = size(index,2);
Frequency=[Frequency a];

index=find('Y'==x);
a = size(index,2);
Frequency=[Frequency a];

return