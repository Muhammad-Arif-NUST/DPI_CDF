%fastaFile �������е��ļ�
%p cell�ͣ�ÿ��protein���е�PSSM����

function p = blastpssm_seq(seq, db)
%seq='MSPFFMMSLLFGLTFGQTASVCAPSEYTIHVEKRECAYCLAINTTICAGFCMTRDSNGKKLLLKSALSQNVCTYKEMFYQTALIPGCPHHTIPYYSYPVAISCKCGKCNTDYSDCVHEKVRTNYCTKPQKLCNM'
%db='D:\NCBI\blast-2.6.0+\db\Swissport'
heads = 'Lala';
seqs = seq;

%cmd = ['E:/NCBI/blast-2.2.28+/bin/psiblast -db ' db ' -query inputtmp.fasta -num_alignments 3  -evalue 0.001  -outfmt 6  -out_ascii_pssm pssmresult'];% -num_alignments
cmd = ['E:\NCBI\blast-2.6.0+\bin/psiblast -db ' db ' -query inputtmp.fasta -num_iterations 3 -evalue 0.001 -out_ascii_pssm pssmresult'];

if ~ischar(heads)
    row = length(heads);
    p = cell(1,row);
    for k = 1 : row
        fid_in = fopen('inputtmp.fasta','w');
        fprintf(fid_in,seqs{k});
        fclose(fid_in);

        system(cmd);
        M = zeros(length(seqs{k}),40);

        fid_out = fopen('pssmresult','r');
        for i = 1 : 4
            tline=fgetl(fid_out);
        end
        i = 1;
        while ischar(tline) && ~isempty(tline)
            A = sscanf(tline,'%d %s %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d');
            M(i,:) = A(3:42)';
            i=i+1;
            tline=fgetl(fid_out);
        end
        p{k}=M;
        fclose(fid_out);
    end
else 
    p = zeros(length(seqs),40);
    fid_in = fopen('inputtmp.fasta','w');
    fprintf(fid_in,seqs);
    fclose(fid_in);

    system(cmd);
    fid_out = fopen('pssmresult','r');
    for i = 1 : 4
        tline=fgetl(fid_out);
    end
    i = 1;
    while ischar(tline) && ~isempty(tline)
        A = sscanf(tline,'%d %s %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d');
        p(i,:) = A(3:42)';
        i=i+1;
        tline=fgetl(fid_out);
    end
     fclose(fid_out);
end