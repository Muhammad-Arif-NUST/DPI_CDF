clc;
clear all;
feature_QLC=[];

[data, sequence] = fastaread('TS_Spider.txt')
Total_Seq_train=size(sequence,2);

for i=1:(Total_Seq_train)
    i
    SEQ=sequence(i);
	FF=mctd(SEQ);
    SEQ=cell2mat(SEQ);
    feature_QLC(i,:)=FF;
end
Drug_QLC_Test=[feature_QLC];
save Drug_QLC_Test Drug_QLC_Test;
csvwrite('Drug_QLC_Test.csv',Drug_QLC_Test);
